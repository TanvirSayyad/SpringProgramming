package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRegistrationformApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRegistrationformApplication.class, args);
		System.out.println("Now am Working");
	}

}
