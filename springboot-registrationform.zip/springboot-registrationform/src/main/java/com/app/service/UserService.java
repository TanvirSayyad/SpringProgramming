package com.app.service;

import com.app.entity.User;

public interface UserService {
    void registerUser(User user);
}
