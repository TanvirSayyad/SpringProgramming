package com.springrest.springrest.Services;

import java.util.List;

import com.springrest.springrest.controller.Course;

public interface CourseService {
	public List<Course>getCourses();

}
