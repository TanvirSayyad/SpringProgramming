package net.javaguides.sms;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import net.javaguides.sms.entity.Student;
import net.javaguides.sms.repository.StudentRepository;
import net.javaguides.sms.test.Calculator;

/**
 * This class contains unit tests for the Student Management System application.
 * It tests the methods in the Calculator class to ensure they work as expected.
 */
@SpringBootTest // Indicates that the class is a Spring Boot test
class StudentManagementSystemApplicationTests {
	
	@Autowired
	private StudentRepository stRepo;
	
	@Test
	void testdatabase() {
		
		Student st=new Student();
		
		String check="Arbaj";
		
		
		st.setFirstName("Arbaj");
		st.setLastName("Sayyad");
		st.setEmail("Sayyad87@gmail.com");
		stRepo.save(st);
		boolean result=stRepo.getOne((long) 5) != null;
		
		assertThat(result).isTrue();
		
		
		
		
		
		
	}
	@AfterEach
	private void teardown() {
		
		stRepo.deleteAll();
		// TODO Auto-generated method stub

	}
	@BeforeEach
	
	private void teardown1() {
		System.out.println("Starting Your Tesating");
	}
	
    
    }

