package net.javaguides.sms.test;

public class Calculator {
public int dosum(int a,int b,int c) {
	return a+b+c;
	
}

public int division(int a,int b) 
{
return a/b;	
}
}
