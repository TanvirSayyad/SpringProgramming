package net.javaguides.sms;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import net.javaguides.sms.repository.StudentRepository;
import net.javaguides.sms.service.StudentServiceImpl;
@ExtendWith(MockitoExtension.class)
public class ServiceTest {
	@Mock
	private StudentRepository Studentrepo;
	
	private StudentServiceImpl std;
	@BeforeEach
	void setup() {
		this.std=new StudentServiceImpl(this.Studentrepo);
		//means student repo have mock data so we redirect mock data to actual object like Student repository
		
		//if we not doing this step it will call aggain main database cause in service class we already autowired repo so thats why 
		
	}
	@Test
	void getAllPerson() {
		
		std.getAllStudents();
		
		verify(Studentrepo).findAll();
	}
}
